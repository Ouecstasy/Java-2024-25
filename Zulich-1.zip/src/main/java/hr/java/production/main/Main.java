package hr.java.production.main;

import hr.java.restaurant.model.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Scanner;

public class Main {
    public static void main(String[] args){
        Scanner skener = new Scanner(System.in);
        Category[] categories = new Category[3];
        for(int i = 0; i < 3; i++){
            System.out.println("Enter " + (i+1) + ". category.");
            categories[i] = enterNewCategory(skener);
        }
        Ingredient[] ingredients = new Ingredient[5];
        for(int i = 0; i < 5; i++){
            System.out.println("Enter " + (i+1) + ". ingredient");
            ingredients[i] = enterNewIngredient(skener);
        }
        Meal[] meals = new Meal[3];
        for(int i = 0; i < 3; i++){
            System.out.println("Enter " + (i+1) + ". meal");
            meals[i] = enternewMeal(skener);
        }
        Chef[] chefs = new Chef[3];
        for(int i = 0; i < 3; i++){
            System.out.println("Enter " + (i+1) + ". chef");
            chefs[i] = enterNewChef(skener);
        }
        Waiter[] waiters = new Waiter[3];
        for(int i = 0; i < 3; i++){
            System.out.println("Enter " + (i+1) + ". waiter");
            waiters[i] = enterNewWaiter(skener);
        }
        Deliverer[] deliverers = new Deliverer[3];
        for(int i = 0; i < 3; i++){
            System.out.println("Enter " + (i+1) + ". deliverer");
            deliverers[i] = enterNewDeliverer(skener);
        }
        Restaurant[] restaurants = new Restaurant[3];
        for(int i = 0; i < 3; i++){
            System.out.println("Enter " + (i+1) + ". restaurant");
            restaurants[i] = enterNewRestaurant(skener);
        }
        Order[] orders = new Order[3];
        for(int i = 0; i < 3; i++){
            System.out.println("Enter " + (i+1) + ". order");
            orders[i] = enterNewOrder(skener);
        }
        printMostExpensiveOrder(restaurants);
        printMostProductiveDeliverer(orders);

    }
    static Category enterNewCategory(Scanner s){
        System.out.println("Enter name");
        String name = enterWord(s);
        System.out.println("Enter description");
        String description = enterWord(s);
        return new Category(name, description);
    }

    static Ingredient enterNewIngredient(Scanner s){
        System.out.println("Enter name of the ingredient");
        String name = enterWord(s);
        System.out.println("Enter category");
        Category category = enterNewCategory(s);
        System.out.println("Enter calories");
        BigDecimal kcal = s.nextBigDecimal();
        System.out.println("Enter prep method");
        String prepMethod = enterWord(s);
        return new Ingredient(name, category, kcal, prepMethod);
    }
    static Meal enternewMeal(Scanner s){
        System.out.println("Enter name");
        String name = enterWord(s);
        System.out.println("Enter category");
        Category category = enterNewCategory(s);
        System.out.println("How many ingredients?");
        Integer num = checkIfEntryIsZero(s);
        System.out.println("Enter ingredients");
        Ingredient[] ingredients = new Ingredient[num];
        for(int i = 0; i < num; i++){
            ingredients[i] = enterNewIngredient(s);
        }
        System.out.println("Enter price");
        BigDecimal price = s.nextBigDecimal();
        return new Meal(name, category, ingredients, price);
    }
    static Chef enterNewChef(Scanner s){
        System.out.println("Enter name");
        String firstName = enterWord(s);
        System.out.println("Enter the chef's last name");
        String lastName = enterWord(s);
        System.out.println("Enter the chef's salary");
        BigDecimal salary = s.nextBigDecimal();
        return new Chef(firstName, lastName, salary);
    }
    static Waiter enterNewWaiter(Scanner s){
        System.out.println("Enter the waiter's name");
        String firstName = enterWord(s);
        System.out.println("Enter the waiter's last name");
        String lastName = enterWord(s);
        System.out.println("Enter the waiter's salary");
        BigDecimal salary = s.nextBigDecimal();
        return new Waiter(firstName, lastName, salary);
    }
    static Deliverer enterNewDeliverer(Scanner s){
        System.out.println("Enter the deliverer's name");
        String firstName = enterWord(s);
        System.out.println("Enter the deliverer's last name");
        String lastName = enterWord(s);
        System.out.println("Enter the deliverer's salary");
        BigDecimal salary = s.nextBigDecimal();
        return new Deliverer(firstName, lastName, salary);
    }
    static Restaurant enterNewRestaurant(Scanner s){
        System.out.println("Enter the restaurant's name");
        String name = enterWord(s);
        System.out.println("Enter the restaurant's address");
        Address address = enterNewAddress(s);
        System.out.println("Enter menu");
        System.out.println("How many menu items?");
        Integer numItems= checkIfEntryIsZero(s);
        Meal[] meals = new Meal[numItems];
        for(int i = 0; i < numItems; i++){
            meals[i] = enternewMeal(s);
        }
        System.out.println("Enter chefs");
        System.out.println("How many chefs?");
        Integer numChefs= checkIfEntryIsZero(s);
        Chef[] chefs = new Chef[numChefs];
        for(int i = 0; i < numChefs; i++){
            chefs[i] = enterNewChef(s);
        }
        System.out.println("Enter waiters");
        System.out.println("How many waiters?");
        Integer numWaiters= checkIfEntryIsZero(s);
        Waiter[] waiters = new Waiter[numWaiters];
        for(int i = 0; i < numWaiters; i++){
            waiters[i] = enterNewWaiter(s);
        }
        System.out.println("Enter deliverers");
        System.out.println("How many deliverers?");
        Integer numDeliverers = checkIfEntryIsZero(s);
        Deliverer[] deliverers = new Deliverer[numDeliverers];
        for(int i = 0; i < numDeliverers; i++){
            deliverers[i] = enterNewDeliverer(s);
        }
        return new Restaurant(name, address, meals, chefs, waiters, deliverers);
    }
    static Address enterNewAddress(Scanner s){
        System.out.println("Enter street");
        String street = enterWord(s);
        System.out.println("Enter house number");
        String houseNumber = enterWord(s);
        System.out.println("Enter city");
        String city = enterWord(s);
        System.out.println("Enter postal code");
        String postalCode = enterWord(s);
        return new Address(street, houseNumber, city, postalCode);
    }

    static Order enterNewOrder(Scanner s){
       System.out.println("Enter restaurant");
        Restaurant restaurant = enterNewRestaurant(s);
        System.out.println("How many meals?");
        Integer numberOfMeals = s.nextInt();
        Meal[] meals = new Meal[numberOfMeals];
        for(int i = 0; i < numberOfMeals; i++){
            meals[i] = enternewMeal(s);
        }
        System.out.println("Enter deliverer");
        Deliverer deliverer = enterNewDeliverer(s);
        System.out.println("Enter delivery time in minutes.");
        LocalDateTime currentTime = LocalDateTime.now();
        Integer minutes = s.nextInt();
        LocalDateTime deliveryDateAndTime = currentTime.plusMinutes(minutes);
        return new Order(restaurant, meals, deliverer, deliveryDateAndTime);
    }
   static String enterWord(Scanner s){
        String word = s.nextLine();
        while(word.length() < 2){
            System.out.println("Word is too short, enter valid word");
            word = s.nextLine();
        }
        return word;
   }
   static void printMostExpensiveOrder(Restaurant[] restaurants){
        BigDecimal highestPrice = new BigDecimal(0);
        for(int i = 0; i < restaurants.length; i++){
            BigDecimal totalPrice = calcTotalPrice(restaurants[i].getMeals());
            if(totalPrice.compareTo(highestPrice) > 0)
                highestPrice = totalPrice;
        }
        for(int i=0; i < restaurants.length; i++){
            BigDecimal currentTotal = calcTotalPrice(restaurants[i].getMeals());
            if(currentTotal.equals(highestPrice))
                System.out.println(restaurants[i].getName());
        }
   }
   static BigDecimal calcTotalPrice(Meal[] meals){
       BigDecimal totalPrice = new BigDecimal(0);
       for(int i = 0; i < meals.length; i++){
           totalPrice = totalPrice.add(meals[i].getPrice());
       }
       return totalPrice;
   }

   static void printMostProductiveDeliverer(Order[] orders){
        Deliverer mostProd = new Deliverer(null, null, null);
        int max = 1;
        int ctr = 1;
        for(int i = 0; i < orders.length; i++){
            ctr = countNames(orders, i);
            if(ctr > max){
                max = ctr;
                mostProd.setFirstName(orders[i].getDeliverer().getFirstName());
                mostProd.setLastName(orders[i].getDeliverer().getLastName());
            }
        }
        boolean flag = false;
        for(int i = 0; i < orders.length; i++){
            ctr = countNames(orders, i);
            if(ctr >= max && orders[i].getDeliverer().getFirstName().equals(mostProd.getFirstName()))
                if(orders[i].getDeliverer().getLastName().equals(mostProd.getLastName()))
                    continue;
            else{
                flag = true;
                break;
            }
        }
         if(!flag)
            System.out.println(mostProd.getFirstName() + mostProd.getLastName());
        else{
            for(int i = 0; i < orders.length; i++){
                System.out.println(orders[i].getDeliverer().getFirstName());
                System.out.println(orders[i].getDeliverer().getLastName());
            }
        }
   }
   static int countNames(Order[] orders, int position){
        int ctr = 1;
        for(int i = 0; i < orders.length; i++){
            if(i == position)
                continue;
            if(orders[position].getDeliverer().getFirstName().equals(orders[i].getDeliverer().getFirstName())){
                if(orders[position].getDeliverer().getLastName().equals(orders[i].getDeliverer().getLastName()))
                    ctr++;
            }
        }
        return ctr;
   }
   static Integer checkIfEntryIsZero(Scanner s){
        Integer num = s.nextInt();
        while(num == 0){
            System.out.println("There has to be at least one entry.");
            num = s.nextInt();
        }
        return num;
   }

}


