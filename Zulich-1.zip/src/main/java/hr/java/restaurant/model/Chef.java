package hr.java.restaurant.model;

import java.math.BigDecimal;

public class Chef {
    String firstName;
    String lastname;
    BigDecimal salary;

    public Chef(String firstName, String lastname, BigDecimal salary) {
        this.firstName = firstName;
        this.lastname = lastname;
        this.salary = salary;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public BigDecimal getSalary() {
        return salary;
    }

    public void setSalary(BigDecimal salary) {
        this.salary = salary;
    }
}
