package hr.java.restaurant.model;

import java.math.BigDecimal;

public class Waiter {
    String firstName;
    String lastName;
    BigDecimal salary;

    public Waiter(String firstName, String lastName, BigDecimal salary) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.salary = salary;
    }

}
