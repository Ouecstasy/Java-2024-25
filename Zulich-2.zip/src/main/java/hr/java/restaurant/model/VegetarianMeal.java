package hr.java.restaurant.model;

import java.math.BigDecimal;

public final class VegetarianMeal extends Meal implements Vegetarian{
    String vegan;
    public VegetarianMeal(String name, Category category, Ingredient[] ingredients, BigDecimal price, String vegan){
        super(name, category, ingredients, price);
        this.vegan = vegan;
    }

    public String getVegan() {
        return vegan;
    }

    public void setVegan(String vegan) {
        this.vegan = vegan;
    }

    public Boolean isVegan(){
        return vegan.contains("Vegan");
    }

    public void printIfVegan(){
        if(vegan.contains("Vegan"))
            System.out.println("It's vegan");
        else
            System.out.println("It's not vegan");
    }
}
