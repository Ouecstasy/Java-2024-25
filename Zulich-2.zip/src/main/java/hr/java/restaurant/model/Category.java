package hr.java.restaurant.model;

public class Category extends Entity{
    String name, description;

    public Category(String name, String description) {
        super(null);
        this.name = name;
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    public static class Builder{
        String name, description;
        public Builder name(String name){
            this.name = name;
            return this;
        }
        public Builder description(String description){
            this.description = description;
            return this;
        }
        public Category build(){
            return new Category(name, description);
        }
    }
}
