package hr.java.restaurant.model;

import java.math.BigDecimal;
import java.time.LocalDate;

public class Contract {
    public static final String CONTRACT_TYPE_FULL = "FULL_TIME";
    public static final String CONTRACT_TYPE_PART = "PART_TIME";
    BigDecimal salary;
    LocalDate startDate, endDate;

    public Contract(BigDecimal salary, LocalDate startDate, LocalDate endDate) {
        this.salary = salary;
        this.startDate = startDate;
        this.endDate = endDate;
    }

    public Contract(BigDecimal salary, LocalDate startDate) {
        this.salary = salary;
        this.startDate = startDate;
    }

    public BigDecimal getSalary() {
        return salary;
    }

    public void setSalary(BigDecimal salary) {
        this.salary = salary;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }
}
