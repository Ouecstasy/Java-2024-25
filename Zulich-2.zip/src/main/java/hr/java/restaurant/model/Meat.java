package hr.java.restaurant.model;

import java.util.Scanner;

public sealed interface Meat permits MeatMeal {
    public void printIfSpicy(String s);
    public Boolean isOrganic(String s);
}
