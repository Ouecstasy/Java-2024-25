package hr.java.restaurant.model;

import java.math.BigDecimal;
import java.util.Scanner;

public final class VeganMeal extends Meal implements Vegan{
    String SourceOfProtein;
    public VeganMeal(String name, Category category, Ingredient[] ingredients, BigDecimal price, String sourceOfProtein){
        super(name, category, ingredients, price);
        this.SourceOfProtein = sourceOfProtein;
    }

    public String getSourceOfProtein() {
        return SourceOfProtein;
    }

    public void setSourceOfProtein(String sourceOfProtein) {
        SourceOfProtein = sourceOfProtein;
    }
    public Boolean isNotMeat(Ingredient ingredient){
        return !ingredient.getCategory().description.contains("Meat");
    }
    public void printMainIngredient(Scanner s){
        System.out.println("Please enter main ingredient");
        String mainIngredient = s.nextLine();
        System.out.println(mainIngredient);
    }
}
