package hr.java.restaurant.model;

import java.math.BigDecimal;

public class Waiter extends Person{
    Contract contract;
    Bonus bonus;

    public Waiter(String firstName, String lastName, Contract contract, Bonus bonus) {
        super(null, firstName, lastName);
        this.contract = contract;
        this.bonus = bonus;
    }


    public Contract getContract() {
        return contract;
    }

    public void setContract(Contract contract) {
        this.contract = contract;
    }

    public static class Builder{
        private String firstName;
        private String lastName;
        private Contract contract;
        private Bonus bonus;
        public Builder firstName(String firstName){
            this.firstName = firstName;
            return this;
        }
        public Builder lastName(String lastName){
            this.lastName = lastName;
            return this;
        }
        public Builder contract(Contract contract){
            this.contract = contract;
            return this;
        }
        public Builder bonus(Bonus bonus){
            this.bonus = bonus;
            return this;
        }
        public Waiter build(){
            return new Waiter(firstName, lastName, contract, bonus);
        }
    }
}
