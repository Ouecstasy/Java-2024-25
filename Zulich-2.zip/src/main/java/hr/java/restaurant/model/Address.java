package hr.java.restaurant.model;

public class Address extends Entity {
    String street, houseNumber, city, postalCode;

    public Address(String street, String houseNumber, String city, String postalCode) {
        super(null);
        this.street = street;
        this.houseNumber = houseNumber;
        this.city = city;
        this.postalCode = postalCode;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getHouseNumber() {
        return houseNumber;
    }

    public void setHouseNumber(String houseNumber) {
        this.houseNumber = houseNumber;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }
    public static class Builder{
        String street, houseNumber, city, postalCode;
        public Builder street(String street){
            this.street = street;
            return this;
        }
        public Builder houseNumber(String houseNumber){
            this.houseNumber = houseNumber;
            return this;
        }
        public Builder city(String city){
            this.city = city;
            return this;
        }
        public Builder postalCode(String postalCode){
            this.postalCode = postalCode;
            return this;
        }
        public Address build(){
            return new Address(street, houseNumber, city, postalCode);
        }
    }
}
