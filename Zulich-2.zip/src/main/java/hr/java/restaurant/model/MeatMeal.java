package hr.java.restaurant.model;

import java.math.BigDecimal;
import java.util.Scanner;

public final class MeatMeal extends Meal implements Meat{
    String organic;
    public MeatMeal(String name, Category category, Ingredient[] ingredients, BigDecimal price, String organic){
        super(name, category, ingredients, price);
        this.organic = organic;
    }

    public String getOrganic() {
        return organic;
    }

    public void setOrganic(String organic) {
        this.organic = organic;
    }

    public void printIfSpicy(String s){
        if(s.contains("Y"))
            System.out.println("It's spicy");
    }

    public Boolean isOrganic(String s){
        return s.contains("Y");
    }
}
