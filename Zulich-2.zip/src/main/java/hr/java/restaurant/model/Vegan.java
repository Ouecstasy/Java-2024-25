package hr.java.restaurant.model;

import java.util.Scanner;

public sealed interface Vegan permits VeganMeal {
    Boolean isNotMeat(Ingredient ingredient);
    void printMainIngredient(Scanner s);
}
