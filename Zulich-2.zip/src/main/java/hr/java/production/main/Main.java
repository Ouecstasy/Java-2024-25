package hr.java.production.main;

import hr.java.restaurant.model.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Scanner;

public class Main {
    public static void main(String[] args){
        Scanner skener = new Scanner(System.in);
        Category[] categories = new Category[3];
        for(int i = 0; i < 3; i++){
            System.out.println("Enter " + (i+1) + ". category.");
            categories[i] = enterNewCategory(skener);
        }
        Ingredient[] ingredients = new Ingredient[5];
        for(int i = 0; i < 5; i++){
            System.out.println("Enter " + (i+1) + ". ingredient");
            ingredients[i] = enterNewIngredient(skener);
        }
        Meal[] meals = new Meal[3];
        for(int i = 0; i < 3; i++){
            System.out.println("Enter " + (i+1) + ". meal");
            meals[i] = enternewMeal(skener);
        }
        Chef[] chefs = new Chef[3];
        for(int i = 0; i < 3; i++){
            System.out.println("Enter " + (i+1) + ". chef");
            chefs[i] = enterNewChef(skener);
        }
        Waiter[] waiters = new Waiter[3];
        for(int i = 0; i < 3; i++){
            System.out.println("Enter " + (i+1) + ". waiter");
            waiters[i] = enterNewWaiter(skener);
        }
        Deliverer[] deliverers = new Deliverer[3];
        for(int i = 0; i < 3; i++){
            System.out.println("Enter " + (i+1) + ". deliverer");
            deliverers[i] = enterNewDeliverer(skener);
        }
        Restaurant[] restaurants = new Restaurant[3];
        for(int i = 0; i < 3; i++){
            System.out.println("Enter " + (i+1) + ". restaurant");
            restaurants[i] = enterNewRestaurant(skener);
        }
        Order[] orders = new Order[3];
        for(int i = 0; i < 3; i++){
            System.out.println("Enter " + (i+1) + ". order");
            orders[i] = enterNewOrder(skener);
        }
        printMostExpensiveOrder(restaurants);
        printMostProductiveDeliverer(orders);

        Person[] employees = new Person[10];
        employees = enterNewEmployees(chefs, deliverers, waiters, employees);

        Person employeeWithHighestSalary = findEmployeeWithHighestSalary(employees);

        Person employeeWithLongestContract = findEmployeeWithLongestContract(employees);
    }
    static Category enterNewCategory(Scanner s){
        System.out.println("Enter name");
        String name = enterWord(s);
        System.out.println("Enter description");
        String description = enterWord(s);
        return new Category.Builder()
                .name(name)
                .description(description)
                .build();
    }

    static Ingredient enterNewIngredient(Scanner s){
        System.out.println("Enter name of the ingredient");
        String name = enterWord(s);
        System.out.println("Enter category");
        Category category = enterNewCategory(s);
        System.out.println("Enter calories");
        BigDecimal kcal = s.nextBigDecimal();
        System.out.println("Enter prep method");
        String prepMethod = enterWord(s);
        return new Ingredient(name, category, kcal, prepMethod);
    }
    static Meal enternewMeal(Scanner s){
        System.out.println("Enter name");
        String name = enterWord(s);
        System.out.println("Enter category");
        Category category = enterNewCategory(s);
        System.out.println("How many ingredients?");
        Integer num = checkIfEntryIsZero(s);
        System.out.println("Enter ingredients");
        Ingredient[] ingredients = new Ingredient[num];
        for(int i = 0; i < num; i++){
            ingredients[i] = enterNewIngredient(s);
        }
        System.out.println("Enter price");
        BigDecimal price = s.nextBigDecimal();
        if(category.getName().equals("meat")){
            System.out.println("Is it organic? Enter Organic or Not Organic");
            String organic = s.nextLine();
            return new MeatMeal(name, category, ingredients, price, organic);
        }
        else if(category.getName().equals("Vegan")){
            System.out.println("Enter source of protein:");
            String sourceOfProtein = s.nextLine();
            return new VeganMeal(name, category, ingredients, price,sourceOfProtein);
        }
        else if(category.getName().equals("Vegetarian")){
            System.out.println("Enter if meal is also vegan:");
            String vegan = s.nextLine();
            return new VegetarianMeal(name, category, ingredients, price, vegan);
        }
        return new Meal(name, category, ingredients, price);
    }
    static Chef enterNewChef(Scanner s){
        System.out.println("Enter name");
        String firstName = enterWord(s);
        System.out.println("Enter the chef's last name");
        String lastName = enterWord(s);
        System.out.println("Enter contract data for the chef");
        Contract contract = enterContract(s);
        System.out.println("Enter the chef's bonus");
        BigDecimal bonusAmount = s.nextBigDecimal();
        Bonus bonus =  new Bonus(bonusAmount);
        return new Chef.Builder()
                .firstName(firstName)
                .lastName(lastName)
                .contract(contract)
                .bonus(bonus)
                .build();
    }
    static Waiter enterNewWaiter(Scanner s){
        System.out.println("Enter the waiter's name");
        String firstName = enterWord(s);
        System.out.println("Enter the waiter's last name");
        String lastName = enterWord(s);
        System.out.println("Enter contract data for the waiter");
        Contract contract = enterContract(s);
        System.out.println("Enter the waiter's bonus");
        BigDecimal bonusAmount = s.nextBigDecimal();
        Bonus bonus = new Bonus(bonusAmount);
        return new Waiter.Builder()
                .firstName(firstName)
                .lastName(lastName)
                .contract(contract)
                .bonus(bonus)
                .build();
    }
    static Deliverer enterNewDeliverer(Scanner s){
        System.out.println("Enter the deliverer's name");
        String firstName = enterWord(s);
        System.out.println("Enter the deliverer's last name");
        String lastName = enterWord(s);
        System.out.println("ENter the deliverer's contract info:");
        Contract contract = enterContract(s);
        System.out.println("Enter the deliverer's bonus");
        BigDecimal bonusAmount = s.nextBigDecimal();
        Bonus bonus = new Bonus(bonusAmount);
        return new Deliverer.Builder()
                .firstName(firstName)
                .lastName(lastName)
                .contract(contract)
                .bonus(bonus)
                .build();
    }
    static Restaurant enterNewRestaurant(Scanner s){
        System.out.println("Enter the restaurant's name");
        String name = enterWord(s);
        System.out.println("Enter the restaurant's address");
        Address address = enterNewAddress(s);
        System.out.println("Enter menu");
        System.out.println("How many menu items?");
        Integer numItems= checkIfEntryIsZero(s);
        Meal[] meals = new Meal[numItems];
        for(int i = 0; i < numItems; i++){
            meals[i] = enternewMeal(s);
        }
        System.out.println("Enter chefs");
        System.out.println("How many chefs?");
        Integer numChefs= checkIfEntryIsZero(s);
        Chef[] chefs = new Chef[numChefs];
        for(int i = 0; i < numChefs; i++){
            chefs[i] = enterNewChef(s);
        }
        System.out.println("Enter waiters");
        System.out.println("How many waiters?");
        Integer numWaiters= checkIfEntryIsZero(s);
        Waiter[] waiters = new Waiter[numWaiters];
        for(int i = 0; i < numWaiters; i++){
            waiters[i] = enterNewWaiter(s);
        }
        System.out.println("Enter deliverers");
        System.out.println("How many deliverers?");
        Integer numDeliverers = checkIfEntryIsZero(s);
        Deliverer[] deliverers = new Deliverer[numDeliverers];
        for(int i = 0; i < numDeliverers; i++){
            deliverers[i] = enterNewDeliverer(s);
        }
        return new Restaurant(null, name, address, meals, chefs, waiters, deliverers);
    }
    static Address enterNewAddress(Scanner s){
        System.out.println("Enter street");
        String street = enterWord(s);
        System.out.println("Enter house number");
        String houseNumber = enterWord(s);
        System.out.println("Enter city");
        String city = enterWord(s);
        System.out.println("Enter postal code");
        String postalCode = enterWord(s);
        return new Address.Builder()
                .street(street)
                .houseNumber(houseNumber)
                .city(city)
                .postalCode(postalCode)
                .build();
    }

    static Order enterNewOrder(Scanner s){
       System.out.println("Enter restaurant");
        Restaurant restaurant = enterNewRestaurant(s);
        System.out.println("How many meals?");
        Integer numberOfMeals = s.nextInt();
        Meal[] meals = new Meal[numberOfMeals];
        for(int i = 0; i < numberOfMeals; i++){
            meals[i] = enternewMeal(s);
        }
        System.out.println("Enter deliverer");
        Deliverer deliverer = enterNewDeliverer(s);
        System.out.println("Enter delivery time in minutes.");
        LocalDateTime currentTime = LocalDateTime.now();
        Integer minutes = s.nextInt();
        LocalDateTime deliveryDateAndTime = currentTime.plusMinutes(minutes);
        return new Order(restaurant, meals, deliverer, deliveryDateAndTime);
    }
   static String enterWord(Scanner s){
        String word = s.nextLine();
        while(word.length() < 2){
            System.out.println("Word is too short, enter valid word");
            word = s.nextLine();
        }
        return word;
   }
   static void printMostExpensiveOrder(Restaurant[] restaurants){
        BigDecimal highestPrice = new BigDecimal(0);
        for(int i = 0; i < restaurants.length; i++){
            BigDecimal totalPrice = calcTotalPrice(restaurants[i].getMeals());
            if(totalPrice.compareTo(highestPrice) > 0)
                highestPrice = totalPrice;
        }
        for(int i=0; i < restaurants.length; i++){
            BigDecimal currentTotal = calcTotalPrice(restaurants[i].getMeals());
            if(currentTotal.equals(highestPrice))
                System.out.println(restaurants[i].getName());
        }
   }
   static BigDecimal calcTotalPrice(Meal[] meals){
       BigDecimal totalPrice = new BigDecimal(0);
       for(int i = 0; i < meals.length; i++){
           totalPrice = totalPrice.add(meals[i].getPrice());
       }
       return totalPrice;
   }

    static void printMostProductiveDeliverer(Order[] orders) {
        // Use Builder pattern to initialize most productive deliverer with no names initially
        Deliverer.Builder builder = new Deliverer.Builder();
        Deliverer mostProd = builder.firstName(null).lastName(null).contract(null).bonus(null).build();

        int max = 1;
        int ctr;

        // Loop to find the most productive deliverer based on order count
        for (int i = 0; i < orders.length; i++) {
            ctr = countNames(orders, i);
            if (ctr > max) {
                max = ctr;
                // Use builder to update most productive deliverer’s details
                mostProd = new Deliverer.Builder()
                        .firstName(orders[i].getDeliverer().getFirstName())
                        .lastName(orders[i].getDeliverer().getLastName())
                        .contract(orders[i].getDeliverer().getContract())
                        .bonus(orders[i].getDeliverer().getBonus())
                        .build();
            }
        }

        boolean flag = false;

        // Verify if there is more than one deliverer with max productivity
        for (int i = 0; i < orders.length; i++) {
            ctr = countNames(orders, i);
            Deliverer currentDeliverer = orders[i].getDeliverer();

            if (ctr >= max && currentDeliverer.getFirstName().equals(mostProd.getFirstName()) &&
                    currentDeliverer.getLastName().equals(mostProd.getLastName())) {
                continue;
            } else {
                flag = true;
                break;
            }
        }

        // Print the results based on flag status
        if (!flag) {
            System.out.println(mostProd.getFirstName() + " " + mostProd.getLastName());
        } else {
            for (Order order : orders) {
                System.out.println(order.getDeliverer().getFirstName());
                System.out.println(order.getDeliverer().getLastName());
            }
        }
    }

    static int countNames(Order[] orders, int position){
        int ctr = 1;
        for(int i = 0; i < orders.length; i++){
            if(i == position)
                continue;
            if(orders[position].getDeliverer().getFirstName().equals(orders[i].getDeliverer().getFirstName())){
                if(orders[position].getDeliverer().getLastName().equals(orders[i].getDeliverer().getLastName()))
                    ctr++;
            }
        }
        return ctr;
   }
   static Integer checkIfEntryIsZero(Scanner s){
        Integer num = s.nextInt();
        while(num == 0){
            System.out.println("There has to be at least one entry.");
            num = s.nextInt();
        }
        return num;
   }

   public static Contract enterContract(Scanner s){
        System.out.println("Enter Salary");
        BigDecimal salary = s.nextBigDecimal();
        System.out.println("Enter start date");
        LocalDate startDate = LocalDate.parse(s.nextLine());
        return new Contract(salary, startDate);
   }
    public static Person[] enterNewEmployees(Chef[] chefs, Deliverer[] deliverers, Waiter[] waiters, Person[] employees){
        int index = 0;
        for (int i = 0; i < chefs.length; i++){
            employees[i] = chefs[i];
            index = i;
        }
        for(int i = index + 1; i < waiters.length; i++){
            employees[i] = waiters[i];
            index = i;
        }
        for(int i = index + 1; i < deliverers.length; i++){
            employees[i] = deliverers[i];
        }
        return employees;
    }

    public static Person findEmployeeWithLongestContract(Person[] employees) {
        Person longestContractEmployee = null;
        LocalDate earliestStartDate = LocalDate.now();

        for (Person employee : employees) {
            // Check if the employee has a contract
            if (employee instanceof Chef chef) {
                if (chef.getContract().getStartDate().isBefore(earliestStartDate)) {
                    earliestStartDate = chef.getContract().getStartDate();
                    longestContractEmployee = chef;
                }
            } else if (employee instanceof Waiter waiter) {
                if (waiter.getContract().getStartDate().isBefore(earliestStartDate)) {
                    earliestStartDate = waiter.getContract().getStartDate();
                    longestContractEmployee = waiter;
                }
            } else if (employee instanceof Deliverer deliverer) {
                if (deliverer.getContract().getStartDate().isBefore(earliestStartDate)) {
                    earliestStartDate = deliverer.getContract().getStartDate();
                    longestContractEmployee = deliverer;
                }
            }
        }

        return longestContractEmployee;
    }
    private static Person findEmployeeWithHighestSalary(Person[] employees) {
        Person highestSalaryEmployee = null;
        BigDecimal maxSalary = BigDecimal.ZERO;

        for (Person employee : employees) {
            Contract contract = null;

            // Access the contract based on the specific subclass
            if (employee instanceof Chef chef) {
                contract = chef.getContract();
            } else if (employee instanceof Waiter waiter) {
                contract = waiter.getContract();
            } else if (employee instanceof Deliverer deliverer) {
                contract = deliverer.getContract();
            }

            // If contract exists, compare salary
            if (contract != null && contract.getSalary().compareTo(maxSalary) > 0) {
                maxSalary = contract.getSalary();
                highestSalaryEmployee = employee;
            }
        }
        return highestSalaryEmployee;
    }
}


