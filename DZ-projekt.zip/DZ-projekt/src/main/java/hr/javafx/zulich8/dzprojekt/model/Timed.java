package hr.javafx.zulich8.dzprojekt.model;

import java.time.Duration;
import java.time.LocalDateTime;

public interface Timed {
    LocalDateTime getDeadline();
    Boolean isExpired();
}
