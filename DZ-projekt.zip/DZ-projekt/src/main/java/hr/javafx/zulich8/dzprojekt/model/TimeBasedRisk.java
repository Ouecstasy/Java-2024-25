package hr.javafx.zulich8.dzprojekt.model;
import java.time.Duration;
import java.time.LocalDateTime;

public class TimeBasedRisk extends Risk implements Timed {
    public TimeBasedRisk(Long id, String probability, String impact, String source, Category category) {
        super(id, probability, impact, source, category);
    }

    @Override
    public LocalDateTime getDeadline() {
        return null;
    }

    @Override
    public Boolean isExpired() {
        return false;
    }
}
