package hr.javafx.zulich8.dzprojekt.model;

public class FinancialRisk extends Risk implements Financial{
    Double estimatedLoss, probability;
    public FinancialRisk(Long id, String probability, String impact, String source, Category category) {
        super(id, probability, impact, source, category);
    }

    @Override
    public Double estimateLoss() {
        return estimatedLoss;
    }

    @Override
    public Double estimateProbability() {
        return probability;
    }

    @Override
    public Double calculateExposure(){
        return estimatedLoss * probability;
    }

    @Override
    public Boolean exceedsThreshold(Double value, Double threshold) {
        return value.compareTo(threshold) > 0;
    }
}
