package hr.javafx.zulich8.dzprojekt.enumeration;

public enum LevelOfRisk {
    HIGH, MEDIUM, LOW
}
