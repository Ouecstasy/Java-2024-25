package hr.javafx.zulich8.dzprojekt.model;

import hr.javafx.zulich8.dzprojekt.enumeration.LevelOfRisk;

public class SituationalRisk extends Risk {

    public SituationalRisk(Long id, String probability, String impact, String source, Category category) {
        super(id, probability, impact, source, category);
    }
}
