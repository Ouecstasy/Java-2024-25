package hr.javafx.zulich8.dzprojekt.model;

public interface Situational {
    String getTriggerCondition();
}
