package hr.javafx.zulich8.dzprojekt.model;
/**
 * Superclass for all other classes in "model" package
 */
public abstract class Entity {
    Long id;
    public Entity(Long id) {
        this.id = id;
    }
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
}
