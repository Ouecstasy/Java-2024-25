package hr.javafx.zulich8.dzprojekt.enumeration;

public enum CategoryOfRisk {
    SITUATIONAL, TIME_RELATED, TIME_BASED
}
