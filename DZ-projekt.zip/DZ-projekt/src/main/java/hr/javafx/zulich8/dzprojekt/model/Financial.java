package hr.javafx.zulich8.dzprojekt.model;

public interface Financial {
    Double estimateLoss();
    Double estimateProbability();
    Double calculateExposure();
    Boolean exceedsThreshold(Double value, Double threshold);
}
