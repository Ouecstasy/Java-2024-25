package hr.javafx.zulich8.dzprojekt.model;

public class Risk extends Entity{
    String probability, impact, source;
    Category category;

    public Risk(Long id, String probability, String impact, String source, Category category) {
        super(id);
        this.probability = probability;
        this.impact = impact;
        this.source = source;
        this.category = category;
    }

    public String getProbability() {
        return probability;
    }

    public void setProbability(String probability) {
        this.probability = probability;
    }

    public String getImpact() {
        return impact;
    }

    public void setImpact(String impact) {
        this.impact = impact;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }
}
