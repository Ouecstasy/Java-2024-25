package hr.javafx.zulich8.dzprojekt.model;

import java.time.LocalDateTime;

public class RiskMitigationPlan extends Entity {
    Risk risk;
    String objective, responsiblePerson, description, status;
    LocalDateTime startDate, endDate;

    public RiskMitigationPlan(Long id, Risk risk) {
        super(id);
        this.risk = risk;
    }
}
