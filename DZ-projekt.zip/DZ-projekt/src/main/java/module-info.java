module hr.javafx.zulich8.dzprojekt {
    requires javafx.controls;
    requires javafx.fxml;


    opens hr.javafx.zulich8.dzprojekt to javafx.fxml;
    exports hr.javafx.zulich8.dzprojekt;
    exports hr.javafx.zulich8.dzprojekt.controller;
    opens hr.javafx.zulich8.dzprojekt.controller to javafx.fxml;
    exports hr.javafx.zulich8.dzprojekt.main;
    opens hr.javafx.zulich8.dzprojekt.main to javafx.fxml;
}