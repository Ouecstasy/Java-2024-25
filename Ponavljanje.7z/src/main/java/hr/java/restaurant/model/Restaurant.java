package hr.java.restaurant.model;

import java.util.Arrays;
import java.util.Objects;
import java.util.Set;

public class Restaurant extends Entity {
    String name;
    Address address;
    Set<Meal> meals;
    Set<Chef> chefs;
    Set<Deliverer> deliverers;
    Set<Waiter> waiters;

    public Restaurant(Long id, String name, Address address, Set<Meal> meals, Set<Chef> chefs, Set<Deliverer> deliverers, Set<Waiter> waiters) {
        super(id);
        this.name = name;
        this.address = address;
        this.meals = meals;
        this.chefs = chefs;
        this.deliverers = deliverers;
        this.waiters = waiters;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public Meal[] getMeals() {
        return meals;
    }

    public void setMeals(Meal[] meals) {
        this.meals = meals;
    }

    public Chef[] getChefs() {
        return chefs;
    }

    public void setChefs(Chef[] chefs) {
        this.chefs = chefs;
    }

    public Deliverer[] getDeliverers() {
        return deliverers;
    }

    public void setDeliverers(Deliverer[] deliverers) {
        this.deliverers = deliverers;
    }

    public Waiter[] getWaiters() {
        return waiters;
    }

    public void setWaiters(Waiter[] waiters) {
        this.waiters = waiters;
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Restaurant that)) return false;
        return Objects.equals(getName(), that.getName()) && Objects.equals(getAddress(), that.getAddress()) && Objects.deepEquals(getMeals(), that.getMeals()) && Objects.deepEquals(getChefs(), that.getChefs()) && Objects.deepEquals(getDeliverers(), that.getDeliverers()) && Objects.deepEquals(getWaiters(), that.getWaiters());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getName(), getAddress(), Arrays.hashCode(getMeals()), Arrays.hashCode(getChefs()), Arrays.hashCode(getDeliverers()), Arrays.hashCode(getWaiters()));
    }

    @Override
    public String toString() {
        return "Restaurant{" +
                "name='" + name + '\'' +
                ", address=" + address +
                ", meals=" + Arrays.toString(meals) +
                ", chefs=" + Arrays.toString(chefs) +
                ", deliverers=" + Arrays.toString(deliverers) +
                ", waiters=" + Arrays.toString(waiters) +
                '}';
    }
}
