package hr.java.restaurant.model;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Set;

public class Order extends Entity {
    Restaurant restaurant;
    List<Meal> meals;
    Chef chef;
    Deliverer deliverer;
    Waiter waiter;
    LocalDateTime deliveryDateAndTime;

    public Order(Long id, Restaurant restaurant, List<Meal> meals, Chef chef, Deliverer deliverer, Waiter waiter, LocalDateTime deliveryDateAndTime) {
        super(id);
        this.restaurant = restaurant;
        this.meals = meals;
        this.chef = chef;
        this.deliverer = deliverer;
        this.waiter = waiter;
        this.deliveryDateAndTime = deliveryDateAndTime;
    }

    public Restaurant getRestaurant() {
        return restaurant;
    }

    public void setRestaurant(Restaurant restaurant) {
        this.restaurant = restaurant;
    }

    public Set<Meal> getMeals() {
        return meals;
    }

    public void setMeals(Set<Meal> meals) {
        this.meals = meals;
    }

    public Chef getChef() {
        return chef;
    }

    public void setChef(Chef chef) {
        this.chef = chef;
    }

    public Deliverer getDeliverer() {
        return deliverer;
    }

    public void setDeliverer(Deliverer deliverer) {
        this.deliverer = deliverer;
    }

    public Waiter getWaiter() {
        return waiter;
    }

    public void setWaiter(Waiter waiter) {
        this.waiter = waiter;
    }

    public LocalDateTime getDeliveryDateAndTime() {
        return deliveryDateAndTime;
    }

    public void setDeliveryDateAndTime(LocalDateTime deliveryDateAndTime) {
        this.deliveryDateAndTime = deliveryDateAndTime;
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Order order)) return false;
        if (!super.equals(o)) return false;
        return Objects.equals(getRestaurant(), order.getRestaurant()) && Objects.equals(getMeals(), order.getMeals()) && Objects.equals(getChef(), order.getChef()) && Objects.equals(getDeliverer(), order.getDeliverer()) && Objects.equals(getWaiter(), order.getWaiter()) && Objects.equals(getDeliveryDateAndTime(), order.getDeliveryDateAndTime());
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), getRestaurant(), getMeals(), getChef(), getDeliverer(), getWaiter(), getDeliveryDateAndTime());
    }

    @Override
    public String toString() {
        return "Order{" +
                "restaurant=" + restaurant +
                ", meals=" + meals +
                ", chef=" + chef +
                ", deliverer=" + deliverer +
                ", waiter=" + waiter +
                ", deliveryDateAndTime=" + deliveryDateAndTime +
                '}';
    }
}
