package hr.java.restaurant.model;

public sealed interface Meat permits MeatMeal{
    public abstract String getDescription();
    public abstract String countIngredients();
}
