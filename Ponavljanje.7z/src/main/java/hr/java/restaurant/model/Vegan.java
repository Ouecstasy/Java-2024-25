package hr.java.restaurant.model;

public sealed interface Vegan permits VeganMeal {
    public abstract Boolean hasMeat();
    public abstract Boolean hasFishDairyEggs();

}
