package hr.java.restaurant.model;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Set;

public final class MeatMeal extends Meal implements Meat{
    public MeatMeal(Long id, String name, Category category, Set<Ingredient> ingredients, BigDecimal price) {
        super(id, name, category, ingredients, price);
    }

    @Override
    public String getDescription() {
        return "";
    }

    @Override
    public String countIngredients() {
        return "";
    }

    @Override
    public String toString() {
        return "MeatMeal{" +
                "name='" + name + '\'' +
                ", category=" + category +
                ", ingredients=" + ingredients +
                ", price=" + price +
                '}';
    }
}
