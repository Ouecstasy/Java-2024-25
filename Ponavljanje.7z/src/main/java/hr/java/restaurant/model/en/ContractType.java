package hr.java.restaurant.model.en;

public enum ContractType {
    FULL_TIME,
    PART_TIME
}
