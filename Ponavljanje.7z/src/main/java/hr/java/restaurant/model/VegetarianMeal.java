package hr.java.restaurant.model;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Objects;
import java.util.Set;

public final class VegetarianMeal extends Meal implements Vegetarian{
    String[] meats = {"meat", "chicken", "pig", "swine", "poultry", "mutton", "goose", "ham", "salami", "mortadella", "bacon", "sheep", "horse", "horsemeat"};

    public VegetarianMeal(Long id, String name, Category category, Set<Ingredient> ingredients, BigDecimal price) {
        super(id, name, category, ingredients, price);
    }

    public String[] getMeats() {
        return meats;
    }

    public void setMeats(String[] meats) {
        this.meats = meats;
    }

    @Override
    public Boolean containsMeat() {
        Boolean checkMeat = false;
        for(Ingredient ingredient : getIngredients()) {
            for(String meat : meats) {
                if(ingredient.getName().equals(meat)) {
                    checkMeat = true;
                }
            }
        }
        return checkMeat;
    }

    @Override
    public Integer countIngredients() {
        Integer count = 0;
        for(Ingredient ingredient : getIngredients()) {
            count++;
        }
        return count;
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof VegetarianMeal that)) return false;
        if (!super.equals(o)) return false;
        return Objects.deepEquals(getMeats(), that.getMeats());
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), Arrays.hashCode(getMeats()));
    }

    @Override
    public String toString() {
        return "VegetarianMeal{" +
                "name='" + name + '\'' +
                ", category=" + category +
                ", ingredients=" + ingredients +
                ", price=" + price +
                '}';
    }
}
