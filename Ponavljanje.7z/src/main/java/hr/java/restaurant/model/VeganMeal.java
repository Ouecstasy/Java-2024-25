package hr.java.restaurant.model;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Objects;
import java.util.Set;

public final class VeganMeal extends Meal implements Vegan {
    String[] meats = {"meat", "chicken", "pig", "swine", "poultry", "mutton", "goose", "ham", "salami", "mortadella", "bacon", "sheep", "horse", "horsemeat"};
    String[] fishDairyEggs = {"milk", "dairy", "yoghurt", "eggs", "egg", "kefir", "ayran", "cream", "ice cream", "fish", "bass", "carp"};
    public VeganMeal(Long id, String name, Category category, Set<Ingredient> ingredients, BigDecimal price) {
        super(id, name, category, ingredients, price);
    }



    @Override
    public Boolean hasMeat() {
        Boolean checkMeat = false;
        for(Ingredient ingredient : getIngredients()) {
            for(String meat : meats) {
                if(ingredient.getName().equals(meat)) {
                    checkMeat = true;
                }
            }
        }
        return checkMeat;
    }

    @Override
    public Boolean hasFishDairyEggs() {
        Boolean checkFishDairyEgg = false;
        for(Ingredient ingredient : getIngredients()) {
            for(String fishDairyEgg : fishDairyEggs) {
                if(ingredient.getName().equals(fishDairyEgg)) {
                    checkFishDairyEgg = true;
                }
            }
        }
        return checkFishDairyEgg;
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof VeganMeal veganMeal)) return false;
        if (!super.equals(o)) return false;
        return Objects.deepEquals(meats, veganMeal.meats) && Objects.deepEquals(fishDairyEggs, veganMeal.fishDairyEggs);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), Arrays.hashCode(meats), Arrays.hashCode(fishDairyEggs));
    }

    @Override
    public String toString() {
        return "VeganMeal{" +
                "name='" + name + '\'' +
                ", category=" + category +
                ", ingredients=" + ingredients +
                ", price=" + price +
                '}';
    }
}
