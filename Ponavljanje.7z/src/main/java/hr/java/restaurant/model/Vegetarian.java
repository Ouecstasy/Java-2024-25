package hr.java.restaurant.model;

public sealed interface Vegetarian permits VegetarianMeal {
    public abstract Boolean containsMeat();
    public abstract Integer countIngredients();
}
