package hr.java.restaurant.model.sort;

import hr.java.restaurant.model.Contract;

import java.util.Comparator;

public class ContractDurationComparator implements Comparator<Contract> {
    @Override
    public int compare(Contract o1, Contract o2) {
        return 0;
    }
}
