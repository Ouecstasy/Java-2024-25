package hr.java.restaurant.model;

import java.math.BigDecimal;
import java.util.Objects;

public class Waiter extends Person {
    Contract contract;
    Bonus bonus;

    public Waiter(Long id, String firstName, String lastName, Contract contract, Bonus bonus) {
        super(id, firstName, lastName);
        this.contract = contract;
        this.bonus = bonus;
    }

    public Contract getContract() {
        return contract;
    }

    public void setContract(Contract contract) {
        this.contract = contract;
    }

    public Bonus getBonus() {
        return bonus;
    }

    public void setBonus(Bonus bonus) {
        this.bonus = bonus;
    }
    public static class Builder{
        private Long id;
        private String firstName;
        private String lastName;
        private Contract contract;
        private Bonus bonus;
        public Builder id(Long id){
            this.id = id;
            return this;
        }
        public Builder firstName(String firstName){
            this.firstName = firstName;
            return this;
        }
        public Builder lastName(String lastName){
            this.lastName = lastName;
            return this;
        }
        public Builder contract(Contract contract){
            this.contract = contract;
            return this;
        }
        public Builder bonus(Bonus bonus){
            this.bonus = bonus;
            return this;
        }
        public Waiter build(){
            return new Waiter(id, firstName, lastName, contract, bonus);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Waiter waiter)) return false;
        if (!super.equals(o)) return false;
        return Objects.equals(getContract(), waiter.getContract()) && Objects.equals(getBonus(), waiter.getBonus());
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), getContract(), getBonus());
    }

    @Override
    public String toString() {
        return "Waiter{" +
                "contract=" + contract +
                ", bonus=" + bonus +
                '}';
    }
}
