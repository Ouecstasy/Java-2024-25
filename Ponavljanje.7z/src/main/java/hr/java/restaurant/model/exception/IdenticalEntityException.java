package hr.java.restaurant.model.exception;

public class IdenticalEntityException extends RuntimeException {
    public IdenticalEntityException() {
    }

    public IdenticalEntityException(String message) {
        super(message);
    }

    public IdenticalEntityException(String message, Throwable cause) {
        super(message, cause);
    }

    public IdenticalEntityException(Throwable cause) {
        super(cause);
    }

    public IdenticalEntityException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
