package hr.java.restaurant.model;

import java.math.BigDecimal;
import java.util.Objects;

public class Chef extends Person {
    Contract contract;
    Bonus bonus;

    public Chef(Long id, String firstName, String lastName, Contract contract, Bonus bonus) {
        super(id, firstName, lastName);
        this.contract = contract;
        this.bonus = bonus;
    }

    public Contract getContract() {
        return contract;
    }

    public void setContract(Contract contract) {
        this.contract = contract;
    }

    public Bonus getBonus() {
        return bonus;
    }

    public void setBonus(Bonus bonus) {
        this.bonus = bonus;
    }
    public static class Builder{
        private Long id;
        String firstName, lastName;
        Contract contract;
        Bonus bonus;

        public Builder id(Long id){
            this.id = id;
            return this;
        }
        public Builder firstName(String firstName){
            this.firstName = firstName;
            return this;
        }
        public Builder lastName(String lastName){
            this.lastName = lastName;
            return this;
        }
        public Builder contract(Contract contract){
            this.contract = contract;
            return this;
        }
        public Builder bonus(Bonus bonus){
            this.bonus = bonus;
            return this;
        }
        public Chef build(){
            return new Chef(id, firstName, lastName, contract, bonus);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Chef chef)) return false;
        return Objects.equals(getContract(), chef.getContract()) && Objects.equals(getBonus(), chef.getBonus());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getContract(), getBonus());
    }

    @Override
    public String toString() {
        return "Chef{" +
                "firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", contract=" + contract +
                ", bonus=" + bonus +
                '}';
    }
}
