package hr.java.restaurant.model;

import java.math.BigDecimal;
import java.util.Objects;

public class Ingredient extends Entity {
    String name;
    Category category;
    BigDecimal kcal;
    String preparationMethod;

    public Ingredient(Long id, String name, Category category, BigDecimal kcal, String preparationMethod) {
        super(id);
        this.name = name;
        this.category = category;
        this.kcal = kcal;
        this.preparationMethod = preparationMethod;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public BigDecimal getKcal() {
        return kcal;
    }

    public void setKcal(BigDecimal kcal) {
        this.kcal = kcal;
    }

    public String getPreparationMethod() {
        return preparationMethod;
    }

    public void setPreparationMethod(String preparationMethod) {
        this.preparationMethod = preparationMethod;
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Ingredient that)) return false;
        return Objects.equals(getName(), that.getName()) && Objects.equals(getCategory(), that.getCategory()) && Objects.equals(getKcal(), that.getKcal()) && Objects.equals(getPreparationMethod(), that.getPreparationMethod());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getName(), getCategory(), getKcal(), getPreparationMethod());
    }

    @Override
    public String toString() {
        return "Ingredient{" +
                "name='" + name + '\'' +
                ", category=" + category +
                ", kcal=" + kcal +
                ", preparationMethod='" + preparationMethod + '\'' +
                '}';
    }
}
