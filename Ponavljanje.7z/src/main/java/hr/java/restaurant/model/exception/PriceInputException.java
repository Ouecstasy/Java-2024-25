package hr.java.restaurant.model.exception;

public class PriceInputException extends Exception{
    public PriceInputException() {
    }

    public PriceInputException(String message) {
        super(message);
    }

    public PriceInputException(String message, Throwable cause) {
        super(message, cause);
    }

    public PriceInputException(Throwable cause) {
        super(cause);
    }

    public PriceInputException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
