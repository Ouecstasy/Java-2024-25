package hr.java.restaurant.model;

import hr.java.restaurant.model.en.ContractType;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Objects;

public class Contract extends Entity {
    BigDecimal salary;
    LocalDate startDate, endDate;
    ContractType contractType;

    public Contract(Long id, BigDecimal salary, LocalDate startDate, LocalDate endDate, ContractType contractType) {
        super(id);
        this.salary = salary;
        this.startDate = startDate;
        this.endDate = endDate;
        this.contractType = contractType;
    }

    public Contract(Long id, BigDecimal salary, LocalDate startDate, ContractType contractType) {
        super(id);
        this.salary = salary;
        this.startDate = startDate;
        this.contractType = contractType;
    }

    public BigDecimal getSalary() {
        return salary;
    }

    public void setSalary(BigDecimal salary) {
        this.salary = salary;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public ContractType getContractType() {
        return contractType;
    }

    public void setContractType(ContractType contractType) {
        this.contractType = contractType;
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Contract contract)) return false;
        return Objects.equals(getSalary(), contract.getSalary()) && Objects.equals(getStartDate(), contract.getStartDate()) && Objects.equals(getEndDate(), contract.getEndDate()) && getContractType() == contract.getContractType();
    }

    @Override
    public int hashCode() {
        return Objects.hash(getSalary(), getStartDate(), getEndDate(), getContractType());
    }

    @Override
    public String toString() {
        return "Contract{" +
                "salary=" + salary +
                ", startDate=" + startDate +
                ", endDate=" + endDate +
                ", contractType=" + contractType +
                '}';
    }
}
