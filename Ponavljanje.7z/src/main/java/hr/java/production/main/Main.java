package hr.java.production.main;

import hr.java.restaurant.model.*;
import hr.java.restaurant.model.en.ContractType;
import hr.java.restaurant.model.exception.IdenticalEntityException;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

import org.slf4j.LoggerFactory;
import org.slf4j.Logger;


public class Main {
    private static final Logger log = LoggerFactory.getLogger(Main.class);
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        List<Category> categories = enterCategories(sc, 3);
        Set<Ingredient> ingredients = enterIngredients(sc, 3);
        Set<Meal> meals = enterMeals(sc, 3);
        List<Person> persons = enterPersons(sc, 3);
        List<Restaurant> restaurants = enterRestaurants(sc, 3);
        List<Order> orders = enterOrders(sc, 3);
        Map<Meal, List<Restaurant>> restaurantsByMeal = new HashMap<>();

    }
    private static List<Category> enterCategories(Scanner sc, Integer numOfElements) {
        List<Category> categories = new ArrayList<>();
        System.out.println("Enter " + numOfElements + " categories:");
        for(Integer i = 0; i < numOfElements; i++) {
            Boolean isIdenticalEntity = false;
            do{
                try{
                    System.out.println("Enter " + i+1 + ". category name:");
                    String categoryName = sc.nextLine();
                    System.out.println("Enter " + i+1 + ". category description:");
                    String categoryDescription = sc.nextLine();
                    Category newCategory = new Category.Builder().name(categoryName).description(categoryDescription).build();
                    for(int j = 0; j < i; j++){
                        if(newCategory.equals(categories.get(j))){
                            isIdenticalEntity = true;
                            throw new IdenticalEntityException();
                        }
                    }
                    categories.add(newCategory);
                }catch(IdenticalEntityException e) {
                    log.error("Category already exists, please enter a new one.");
                }
            }while(isIdenticalEntity);
        }
        return categories;
    }
    private static Set<Ingredient> enterIngredients(Scanner sc, Integer numOfElements) {
        Set<Ingredient> ingredients = new HashSet<>();
        System.out.println("Enter " + numOfElements + " ingredients:");
        for(int i = 0; i < numOfElements; i++) {
                    log.info("Enter " + i+1 + ". ingredient name:");
                    String ingredientName = sc.nextLine();
                    log.info("Enter " + i+1 + ". ingredient category:");
                    List<Category> category = enterCategories(sc, 1);
                    Category ingredientCategory = category.get(0);
                    log.info("Enter " + i+1 + ". ingredient caloric value:");
                    BigDecimal caloricValue = sc.nextBigDecimal();
                    sc.nextLine();
                    log.info("Enter " + i+1 + ". ingredient preparation method:");
                    String preparationMethod = sc.nextLine();
                    ingredients.add(new Ingredient(null, ingredientName, ingredientCategory, caloricValue, preparationMethod));
        }
        return ingredients;
    }
    private static Set<Meal> enterMeals(Scanner sc, Integer numOfElements) {
        Set<Meal> meals = new HashSet<>();
        for(int i = 0; i < numOfElements; i++) {
            log.info("Enter name of " + i+1 + ". meal:");
            String mealName = sc.nextLine();
            log.info("Enter category of " + i+1 + ". meal:");
            List<Category> category = enterCategories(sc, 1);
            Category mealCategory = category.get(0);
            log.info("Enter number of ingredients for " + i+1 + ". meal:");
            Integer numberOfIngredients = sc.nextInt();
            sc.nextLine();
            System.out.println("Enter ingredients of " + i+1 + ". meal:");
            Set<Ingredient> ingredients = enterIngredients(sc, numberOfIngredients);
            System.out.println("Enter price of " + i+1 + ". meal:");
            BigDecimal price = sc.nextBigDecimal();
            sc.nextLine();
            System.out.println("Enter type of meal: vegan, vegetarian or meat");
            String typeOfMeal = sc.nextLine();
            VeganMeal newVeganMeal = null;
            VegetarianMeal newVegetarianMeal = null;
            MeatMeal newMeatMeal = null;
            if(typeOfMeal.equals("vegan")) {
                meals.add(new VeganMeal(null, mealName, mealCategory, ingredients, price));
            }
            else if(typeOfMeal.equals("vegetarian")) {
                meals.add(new VegetarianMeal(null, mealName, mealCategory, ingredients, price));
            }
            else if(typeOfMeal.equals("meat")) {
                 meals.add(new MeatMeal(null, mealName, mealCategory, ingredients, price));
            }

        }
        return meals;
    }
    private static Set<Chef> enterChefs(Scanner sc, Integer numOfElements) {
        Set<Chef> chefs = new HashSet<>();
        for(Integer i = 0; i < numOfElements; i++) {
                    System.out.println("Enter first name of " + i+1 + ". chef:");
                    String firstName = sc.nextLine();
                    System.out.println("Enter last name of " + i+1 + ". chef:");
                    String lastName = sc.nextLine();
                    System.out.println("Enter contract of " + i+1 + ". chef:");
                    Contract contract = enterContract(sc);
                    System.out.println("Enter bonus of " + i+1 + ". chef:");
                    BigDecimal bonusAmount = BigDecimal.valueOf(0);
                    Bonus bonus = new Bonus(bonusAmount);
                    chefs.add(new Chef.Builder()
                            .firstName(firstName)
                            .lastName(lastName)
                            .contract(contract)
                            .bonus(bonus)
                            .build());
        }
        return chefs;
    }
    private static Set<Waiter> enterWaiters(Scanner sc, Integer numOfElements) {
        Set<Waiter> waiters = new HashSet<>();
        for(Integer i = 0; i < numOfElements; i++) {
            System.out.println("Enter first name of " + i+1 + ". waiter:");
            String firstName = sc.nextLine();
            System.out.println("Enter last name of " + i+1 + ". waiter:");
            String lastName = sc.nextLine();
            System.out.println("Enter contract of " + i+1 + ". waiter:");
            Contract contract = enterContract(sc);
            System.out.println("Enter bonus for " + i+1 + ". waiter:");
            BigDecimal bonusAmount = sc.nextBigDecimal();
            sc.nextLine();
            Bonus bonus = new Bonus(bonusAmount);
            waiters.add(new Waiter.Builder()
                    .firstName(firstName)
                    .lastName(lastName)
                    .contract(contract)
                    .bonus(bonus)
                    .build());
        }
        return waiters;
    }
    private static Set<Deliverer> enterDeliverers(Scanner sc, Integer numOfElements) {
        Set<Deliverer> deliverers = new HashSet<>();
        for(Integer i = 0; i < numOfElements; i++) {
            System.out.println("Enter first name of " + i+1 + ". deliverer:");
            String firstName = sc.nextLine();
            System.out.println("Enter last name of " + i+1 + ". deliverer:");
            String lastName = sc.nextLine();
            System.out.println("Enter contract of " + i+1 + ". deliverer:");
            Contract contract = enterContract(sc);
            System.out.println("Enter bonus for " + i+1 + ". deliverer:");
            BigDecimal bonusAmount = sc.nextBigDecimal();
            sc.nextLine();
            Bonus bonus = new Bonus(bonusAmount);
            deliverers.add( new Deliverer.Builder()
                    .firstName(firstName)
                    .lastName(lastName)
                    .contract(contract)
                    .bonus(bonus)
                    .build());
        }
        return deliverers;
    }
    private static List<Restaurant> enterRestaurants(Scanner sc, Integer numOfElements) {
        List<Restaurant> restaurants = new ArrayList<>();
        for(Integer i = 0; i < numOfElements; i++) {
            System.out.println("Enter name of " + i+1 + ". restaurant:");
            String restaurantName = sc.nextLine();
            System.out.println("Enter address of " + i+1 + ". restaurant:");
            Address address = enterAddress(sc);
            System.out.println("Enter number of meals of " + i+1 + ". restaurant:");
            Integer numberOfMeals = sc.nextInt();
            sc.nextLine();
            Set<Meal> meals = enterMeals(sc, numberOfMeals);
            System.out.println("Enter number of chefs of " + i+1 + ". restaurant:");
            Integer numberOfChefs = sc.nextInt();
            sc.nextLine();
            Set<Chef> chefs = enterChefs(sc, numberOfChefs);
            System.out.println("Enter number of waiters of " + i+1 + ". restaurant:");
            Integer numberOfWaiters = sc.nextInt();
            sc.nextLine();
           Set<Waiter> waiters = enterWaiters(sc, numberOfWaiters);
            System.out.println("Enter number of deliverers of " + i+1 + ". restaurant:");
            Integer numberOfDeliverers = sc.nextInt();
            sc.nextLine();
            Set<Deliverer> deliverers = enterDeliverers(sc, numberOfDeliverers);
            restaurants.add(new Restaurant(null, restaurantName, address, meals, chefs, deliverers, waiters));
        }
        return restaurants;
    }
    private static Address enterAddress(Scanner sc) {
        System.out.println("Enter street:");
        String street = sc.nextLine();
        System.out.println("Enter house number:");
        String houseNumber = sc.nextLine();
        System.out.println("Enter city:");
        String city = sc.nextLine();
        System.out.println("Enter postal code");
        String postalCode = sc.nextLine();
        return new Address.Builder()
                .street(street)
                .houseNumber(houseNumber)
                .city(city)
                .postalCode(postalCode)
                .build();
    }
    private static List<Order> enterOrders(Scanner sc, Integer numOfElements) {
        List<Order> orders = new ArrayList<>();
        for(Integer i = 0; i < numOfElements; i++) {
            System.out.println("Enter restaurant, where " + i+1 + ". order is served:");
            List<Restaurant> restaurants = enterRestaurants(sc, 1);
            Restaurant restaurant = restaurants.get(0);
            System.out.println("Enter number of meals in " + i+1 + ". order:");
            Integer numberOfMeals = sc.nextInt();
            sc.nextLine();
            Set<Meal> meals = enterMeals(sc, numberOfMeals);
            List<Meal> mealsList = new ArrayList<>();
            mealsList.addAll(meals);
            System.out.println("Enter chef who prepared " + i+1 + ". order:");
            Set<Chef> chefs = enterChefs(sc, 1);
            Chef chef = (Chef) chefs.toArray()[0];
            System.out.println("Enter waiter who served the " + i+1 + ". order:");
            Set<Waiter> waiters = enterWaiters(sc, 1);
            Waiter waiter = (Waiter) waiters.toArray()[0];
            System.out.println("Enter deliverer who delivered " + i+1 + ". order:");
            Set<Deliverer> deliverers = enterDeliverers(sc, 1);
            Deliverer deliverer = (Deliverer) deliverers.toArray()[0];
            System.out.println("Enter date and time when " + i+1 + ". order was served:");
            String dateAndTime = sc.nextLine();
            LocalDateTime date = LocalDateTime.parse(dateAndTime);
            orders.add(new Order(null, restaurant, mealsList, chef, deliverer, waiter, date));
        }
        return orders;
    }
    private static Contract enterContract(Scanner sc) {
        System.out.println("Enter contract:");
        System.out.println("Enter Start date:");
        String startDateString = sc.nextLine();
        LocalDate startDate = LocalDate.parse(startDateString);
        System.out.println("Is the person still employed? Y/N:");
        String isEmployed = sc.nextLine();
        LocalDate endDate = null;
        if(isEmployed.equals("N")) {
            System.out.println("Enter end date:");
            String endDateString = sc.nextLine();
            endDate = LocalDate.parse(endDateString);
        }
        System.out.println("Enter salary:");
        BigDecimal salary = sc.nextBigDecimal();
        sc.nextLine();
        ContractType type = ContractType.FULL_TIME;
        System.out.println("Enter contract type:");
        String contractType = sc.nextLine();
        if(contractType.toLowerCase().equals("part time")) {
            type = ContractType.PART_TIME;
        }
        Contract contract = new Contract(null, salary, startDate, type);
        if(isEmployed.equals("N")) { contract = new Contract(null, salary, startDate, endDate, type);}
        return contract;
    }

    private static List<Person> enterPersons(Scanner sc, Integer numOfElements) {
        List<Person> persons = new ArrayList<>();
        for(int i = 0; i < numOfElements; i++) {
            System.out.println("Enter" + i+1 + "chef, waiter or deliverer:");
            System.out.println("Is the person a chef, waiter or deliverer?");
            String profession = sc.nextLine();
            System.out.println("Enter first name:");
            String firstName = sc.nextLine();
            System.out.println("Enter last name:");
            String lastName = sc.nextLine();
            System.out.println("Enter contract information:");
            Contract contract = enterContract(sc);
            System.out.println("Enter bonus:");
            BigDecimal bonusAmount = sc.nextBigDecimal();
            Bonus bonus = new Bonus(bonusAmount);
            if(profession.toLowerCase().equals("chef")) {
                persons.add(new Chef.Builder()
                        .firstName(firstName)
                        .lastName(lastName)
                        .contract(contract)
                        .bonus(bonus)
                        .build());
            }
            else if(profession.toLowerCase().equals("waiter")) {
                persons.add(new Waiter.Builder()
                        .firstName(firstName)
                        .lastName(lastName)
                        .contract(contract)
                        .bonus(bonus)
                        .build());
            }
            else if(profession.toLowerCase().equals("deliverer")) {
                persons.add(new Deliverer.Builder()
                        .firstName(firstName)
                        .lastName(lastName)
                        .contract(contract)
                        .bonus(bonus)
                        .build());
            }
            else {System.out.println("Invalid profession");}
        }
        return persons;
    }
    private static void printMealsInRestaurants(Map<Meal, List<Restaurant>> map) {
        System.out.println("Enter name of Meal:");
        Scanner sc = new Scanner(System.in);
        String mealName = sc.nextLine();
        System.out.println("This meal is served in the following restaurants:");
        boolean mealFound = false;
        for (Map.Entry<Meal, List<Restaurant>> entry : map.entrySet()) {
            Meal meal = entry.getKey();
            if (meal.getName().equalsIgnoreCase(mealName)) {
                mealFound = true;
                List<Restaurant> restaurants = entry.getValue();
                for (Restaurant restaurant : restaurants) {
                    System.out.println(restaurant.getName());
                }
            }
        }

        if (!mealFound) {
            System.out.println("No restaurants serve this meal.");
        }
    }

}
