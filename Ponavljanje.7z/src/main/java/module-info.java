module hr.javafx.zulich8.ponavljanje {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.logging;
    requires org.slf4j;


    opens hr.javafx.zulich8.ponavljanje to javafx.fxml;
    exports hr.javafx.zulich8.ponavljanje;
}